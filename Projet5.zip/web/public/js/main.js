function initGlobal() {
    objMap.initMap();
}
